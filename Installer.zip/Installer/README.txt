Manual
====================

English
-----------
1. Start the application.
2. Configure if you want to set a maximum duration.
3. Configure if you want to use a key to stop the process.
4. Left-click on the Fortnite window to start.
5. The application will begin simulating movements automatically.

Espa�ol
-----------
1. Inicia la aplicaci�n.
2. Configura si quieres establecer una duraci�n m�xima.
3. Configura si quieres usar una tecla para detener el proceso.
4. Haz clic izquierdo en la ventana de Fortnite para comenzar.
5. La aplicaci�n comenzar� a simular movimientos autom�ticamente.
